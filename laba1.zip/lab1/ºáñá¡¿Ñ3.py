from typing import List, Optional

class NumberCollection:
    def __init__(self, numbers: List[int]) -> None:
        # Инкапсуляция: сохраняем копию списка
        self._numbers: List[int] = list(numbers)

    def get_even_numbers(self) -> List[int]:
        """Возвращает чётные числа."""
        return [n for n in self._numbers if n % 2 == 0]

    def sum_even_squares(self) -> int:
        """Вычисляет сумму квадратов чётных чисел."""
        return sum(n ** 2 for n in self._numbers if n % 2 == 0)

    def count_even_numbers(self) -> int:
        """Подсчитывает количество чётных чисел."""
        return len(self.get_even_numbers())

    def find_maximum(self) -> Optional[int]:
        """Находит максимальное число в коллекции."""
        return max(self._numbers) if self._numbers else None

    def calculate_average(self) -> float:
        """Вычисляет среднее арифметическое всех элементов."""
        if not self._numbers:
            return 0.0
        return sum(self._numbers) / len(self._numbers)


# Демонстрация работы с несколькими объектами
collection1 = NumberCollection([4, 7, 2, 9, 12, 5, 8, 3])
print("=== Объект 1 ===")
print("Чётные числа:", collection1.get_even_numbers())
print("Количество чётных чисел:", collection1.count_even_numbers())
print("Максимальное число:", collection1.find_maximum())
print("Среднее значение:", collection1.calculate_average())
print("Сумма квадратов чётных:", collection1.sum_even_squares())

collection2 = NumberCollection([10, 15, 20, 25, 30])
print("\n=== Объект 2 ===")
print("Чётные числа:", collection2.get_even_numbers())
print("Количество чётных чисел:", collection2.count_even_numbers())
print("Максимальное число:", collection2.find_maximum())
print("Среднее значение:", collection2.calculate_average())
print("Сумма квадратов чётных:", collection2.sum_even_squares())
