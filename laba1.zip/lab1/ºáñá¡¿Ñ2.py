from typing import List

def is_even(number: int) -> bool:
    """Проверяет, является ли число чётным."""
    return number % 2 == 0

def square(number: int) -> int:
    """Возвращает квадрат числа."""
    return number ** 2

def get_even_numbers(values: List[int]) -> List[int]:
    """Возвращает список чётных чисел из коллекции."""
    return [num for num in values if is_even(num)]

def sum_even_squares(values: List[int]) -> int:
    """Вычисляет сумму квадратов чётных чисел."""
    total = 0
    for number in values:
        if is_even(number):
            total += square(number)
    return total

# Основной блок
numbers: List[int] = [4, 7, 2, 9, 12, 5, 8, 3]

# Отдельная проверка функций is_even() и square()
print("--- Отдельные проверки функций ---")
print(f"is_even(4): {is_even(4)}")
print(f"is_even(7): {is_even(7)}")
print(f"square(4): {square(4)}")
print(f"square(12): {square(12)}")

# Проверка функции get_even_numbers()
print(f"Чётные числа из списка: {get_even_numbers(numbers)}")

# Финальное вычисление
print(f"Сумма квадратов чётных чисел: {sum_even_squares(numbers)}")
