numbers = [4, 7, 2, 9, 12, 5, 8, 3]

# 1. С использованием map и filter
result_map_filter = sum(
    map(
        lambda number: number ** 2,
        filter(lambda number: number % 2 == 0, numbers)
    )
)

# 2. С использованием генераторного выражения
result_generator = sum(n ** 2 for n in numbers if n % 2 == 0)

# 3. Отдельный список квадратов чётных чисел
even_squares_list = list(map(lambda n: n ** 2, filter(lambda n: n % 2 == 0, numbers)))

print("Результат (map + filter):", result_map_filter)
print("Результат (генераторное выражение):", result_generator)
print("Отдельный список квадратов чётных чисел:", even_squares_list)
